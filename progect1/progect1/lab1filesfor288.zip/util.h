/// Blocks for a specified number of milliseconds
void wait_ms(unsigned int milliseconds);
